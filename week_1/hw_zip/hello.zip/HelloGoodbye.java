/* *****************************************************************************
 *  Name:              Christopher Marisco
 *  Coursera User ID:  uuidV4()
 *  Last modified:     March 22, 2021
 **************************************************************************** */
public class HelloGoodbye {

    public static void main(String[] args) {
        System.out.println("Hello " + args[0] + " and " + args[1]);
        System.out.println("Goodbye " + args[1] + " and " + args[0]);
    }
}
